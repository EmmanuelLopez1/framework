Thank you for using our typeface.
This is limited character demo version.
if you would like to consider using it for commercial projects. 
please visit  
http://www.studiotypo.com
Thank you.